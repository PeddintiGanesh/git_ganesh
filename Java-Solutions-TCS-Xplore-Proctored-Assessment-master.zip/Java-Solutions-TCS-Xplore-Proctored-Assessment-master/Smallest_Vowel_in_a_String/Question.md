## Problem Statement

Write a program to print the smallest vowel in a given string

## Input

    matrix

## Output

    a

## Explanation

> The vowels in the given string are `a` and `i`.
> And the alphabetically smallest between them is `a`.
